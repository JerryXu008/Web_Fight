import React, {useState, memo, useCallback, useMemo} from 'react';
 
function Home(props) {
    console.log('Home被渲染了');
    return (
        <div>
            <p>Home</p>
            <button onClick={()=>{props.handler()}}>增加</button>
        </div>
    )
}
function About(props) {
    console.log('About被渲染了');
    return (
        <div>
            <p>About</p>
            <p>{props.user.name}</p>
            <p>{props.user.age}</p>
        </div>
    )
}

const MemoHome = memo(Home);
const MemoAbout = memo(About);

function App() {
    console.log('App被渲染了');
    const [numState, setNumState] = useState(0);
    function increment() {
        setNumState(numState + 1);
    }
  
    //返回数据，只要数据没发生变化，MemoAbout 组件就不会重新渲染
    // const user = {name: 'lnj', age:18};
    const user = useMemo(()=>{
        return {name: 'lnj', age:18};
    }, []);
    return (
        <div>
            <p>numState = {numState}</p>
            <MemoHome handler={increment}/>
            <MemoAbout user={user}/>
        </div>
    )
}
export default App;
