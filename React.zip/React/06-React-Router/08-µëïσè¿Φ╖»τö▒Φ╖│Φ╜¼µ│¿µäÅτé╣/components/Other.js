import React from 'react';

class Other extends React.PureComponent{
    render(){
        return (
            <div>Other</div>
        )
    }
}

export default Other;
