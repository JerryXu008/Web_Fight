import React from 'react';

class Home extends React.PureComponent{
    render(){
        return (
            <div>Home</div>
        )
    }
}

export default Home;
