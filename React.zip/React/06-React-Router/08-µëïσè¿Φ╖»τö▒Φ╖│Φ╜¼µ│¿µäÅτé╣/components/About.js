import React from 'react';

class About extends React.PureComponent{
    render(){
        return (
            <div>About</div>
        )
    }
}

export default About;
