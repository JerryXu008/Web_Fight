import ReactDOM from 'react-dom';
import React from 'react';
import App from './App';
import {BrowserRouter} from 'react-router-dom';
import { Provider } from 'react-redux'

import store from './store/store';

import StoreContext from './connect/context'


ReactDOM.render(
  // <Provider store={store}>
    <StoreContext.Provider value={store}>
       <React.StrictMode>
            <App/>
        </React.StrictMode>
    </StoreContext.Provider>
       
  // </Provider>
    , document.getElementById('root'));
