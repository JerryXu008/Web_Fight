import React from 'react'

const StoreContext = React.createContext({})

export default StoreContext;