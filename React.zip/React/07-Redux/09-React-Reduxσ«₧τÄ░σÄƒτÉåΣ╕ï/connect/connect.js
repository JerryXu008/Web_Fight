import ReactDOM from 'react-dom';
import React from 'react';
// import store from '../store/store';
import StoreContext from './context'
function connect(mapStateToProps, mapDispatchToProps) {
     
    return function enhanceComponent(WrappedComponent) {
        class AdvComponent extends React.PureComponent {

           constructor(props,context){
               super(props,context);
               this.state = {
                   ...mapStateToProps(this.context.getState())
               }

            
           }
           componentDidMount(){
                 this.context.subscribe(()=>{
                    this.setState({
                       ...mapStateToProps(this.context.getState()),
                       //count: store.getState().count
                       a:Math.random()
                    })
                 })
           }

             componentWillUnmount() {
                this.context.unsubscribe();
            }

            render(){

                return <WrappedComponent 
                
                {...this.props} 
                {...mapStateToProps(this.context.getState())}
                {...mapDispatchToProps(this.context.dispatch)}
                >

                </WrappedComponent>
            }
        }
        //保存数据，子组件可以使用
        AdvComponent.contextType = StoreContext
        return AdvComponent;
    }

}
export default connect;