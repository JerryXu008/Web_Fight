module.exports = {
    cors: {
        enable: true,
        package: 'egg-cors',
    }
};
