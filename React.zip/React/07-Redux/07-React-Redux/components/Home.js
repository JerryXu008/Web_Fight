import React from 'react';
import { connect } from 'react-redux'
import {addAction, subAction} from '../store/action';
/*
1.当前使用Redux存在的问题
- 冗余代码太多, 每次使用都需要在构造函数中获取
              每次使用都需要监听和取消监听
- 操作store的代码过于分散

2.如何解决冗余代码太多问题?
使用React-Redux

3.什么是React-Redux
React-Redux是Redux官方的绑定库,能够让我们在组件中更好的读取和操作Redux保存的状态
https://react-redux.js.org/introduction/quick-start
* */


class Home extends React.PureComponent{
    render(){
        return (
            <div>
                {/*通过props来使用redux中保存的数据*/}
                <p>{this.props.count}</p>
                <button onClick={()=>{this.props.increment()}}>递增</button>
            </div>
        )
    }
}
// 在mapStateToProps方法中告诉React-Redux, 需要将store中保存的哪些数据映射到当前组件的props上
const mapStateToProps = (state)=>{
    return {
        count: state.count
    }
};
// 在mapDispatchToProps方法中告诉React-Redux, 需要将哪些派发的任务映射到当前组件的props上
const mapDispatchToProps = (dispatch) =>{
    return {
        increment(){
            dispatch(addAction(1));
        }
    }
};
export default connect(mapStateToProps, mapDispatchToProps)(Home);
