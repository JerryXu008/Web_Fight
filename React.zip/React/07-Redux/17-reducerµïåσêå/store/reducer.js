import {
    ADD_COUNT,
    SUB_COUNT,
    CHANGE_INFO
} from './constants';
import {addAction} from "./action";
import {combineReducers} from 'redux';
/*
1.当前reducer存在的问题?
所有的操作都是在一个reducer中处理的, 如果项目很复杂, 那么会变得非常难以维护

2.如何解决?
对reducer进行拆分

官方文档地址: https://www.redux.org.cn/docs/recipes/StructuringReducers.html
* */
let initialHomeState = {
    count: 666
};
function homeReducer(homeState = initialHomeState, action) {
    switch (action.type) {
        case ADD_COUNT:
            return {...homeState ,count: homeState.count + action.num};
        case SUB_COUNT:
            return {...homeState ,count: homeState.count - action.num};
        default:
            return homeState;
    }
}

let initialAboutState = {
    info: {}
};
function aboutReducer(aboutState = initialAboutState, action) {
    switch (action.type) {
        case CHANGE_INFO:
            return {...aboutState ,info: action.info};
        default:
            return aboutState;
    }
}
/*******************手动合并********************************/
// function reducer(state = {}, action) {
//     return {
//         countData: homeReducer(state.countData, action),
//         infoData: aboutReducer(state.infoData, action)
//     }
// }

const reducer = combineReducers({
    countData: homeReducer,
    infoData: aboutReducer
});
export default reducer;


