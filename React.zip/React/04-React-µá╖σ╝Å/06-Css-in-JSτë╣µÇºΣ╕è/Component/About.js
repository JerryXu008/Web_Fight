import React from 'react';

class Home extends React.Component{
    render() {
        return (
            <div>
                <p>我是about段落</p>
                <a href={'www.it666.com'}>我是about超链接</a>
            </div>
        )
    }
}
export default Home;
