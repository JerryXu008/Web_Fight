import React from 'react';
import './Header.css'

function Header() {
    return (
        <div className={'header'}>我是头部2</div>
    )
}
export default Header;
