import React from 'react';
import './Footer.css'
import Main from "./Main";

function Footer() {
    return (
        <div className={'footer'}>我是底部2</div>
    )
}
export default Footer;
