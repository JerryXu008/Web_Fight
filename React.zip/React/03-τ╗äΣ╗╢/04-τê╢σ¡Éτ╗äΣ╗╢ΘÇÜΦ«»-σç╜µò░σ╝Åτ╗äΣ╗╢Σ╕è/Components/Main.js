import React from 'react';
import './Main.css'

function Main() {
    return (
        <div className={'main'}>我是中间2</div>
    )
}
export default Main;
