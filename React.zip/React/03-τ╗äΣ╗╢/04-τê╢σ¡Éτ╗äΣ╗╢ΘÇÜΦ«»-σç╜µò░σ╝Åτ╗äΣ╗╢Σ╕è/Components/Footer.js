import React from 'react';
import './Footer.css'

function Footer() {
    return (
        <div className={'footer'}>我是底部2</div>
    )
}
export default Footer;
