import React from 'react';
import './Header.css'

function Header(props) {
    console.log(props);
    
    return (
        <div className={'header'}>我是头部2</div>
    )
}
export default Header;
